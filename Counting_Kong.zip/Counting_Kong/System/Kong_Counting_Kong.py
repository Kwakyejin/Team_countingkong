import cv2,sys,datetime,math
import time as t
import numpy as np

def get_dish(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blr = cv2.GaussianBlur(gray, (0, 0), 1)

    circles = cv2.HoughCircles(blr, cv2.HOUGH_GRADIENT, 1, 100, None, param1 = 120, param2 = 75, minRadius = 300, maxRadius = 650)

    dst = img.copy()
    if circles is not None:
        cx, cy, radius = map(int,circles[0][0])
        cv2.circle(dst, (cx, cy), radius, (0, 0, 255), 2, cv2.LINE_AA)
        cut = img.copy()
        for i in range(cut.shape[0]):
            for j in range(cut.shape[1]):
                if (i-cy)**2+(j-cx)**2>=radius**2:
                    cut[i,j] = 0
        return {"drow_img":dst,"cut_img":cut[max(0,cy-radius):min(cy+radius,cut.shape[0]),max(0,cx-radius):min(cx+radius,cut.shape[1])]}

def get_beans(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array([15, 54, 54]), np.array([25, 255, 2555]))
    for i in range(mask.shape[0]):
        for j in range(mask.shape[1]):
            if mask[i][j] == 0:
                hsv[i][j] = 0
    return cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR), len(np.nonzero(mask)[0])

def get_result(img,w):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blr = cv2.GaussianBlur(gray, (0, 0), 3)

    circles = cv2.HoughCircles(blr, cv2.HOUGH_GRADIENT, 1, 15,
                               param1=20, param2=12, minRadius=7,
                               maxRadius=17)
    if circles is None: return 0, 0

    for i in range(circles.shape[1]):
        _, _, radius = circles[0][i]
        w -= radius * radius * math.pi
    return circles.shape[1], w

def Solution(cases):
    result = {}
    dic_path = "../../Open/t"
    for i in range(1,cases+1):
        if i < 10: num = "0"+str(i)
        else: num = str(i)
        path = dic_path+num+"/5.jpg"
        src = cv2.imread(path)
        if src is None:
            print(num + ' Image open failed!')
            sys.exit()
        src = cv2.resize(src, dsize=(0, 0), fx=0.3, fy=0.3, interpolation=cv2.INTER_LINEAR)
        got = get_dish(src)

        if got is None:
            print(num,"dish not found")
            result[i] = 0
            continue
        
        cut_img = got["cut_img"]

        if cut_img is None:
            print(num,"cut_img is None")
            result[i] = 0
            continue
        
        beans_img,w = get_beans(cut_img)
        result[i],w = get_result(beans_img,w)
        
        if 30000 >= w >= 17000: result[i]*=1.4
        elif 30000 <= w  < 35000: result[i]*=1.8
        elif 35000 <= w < 60000: result[i] *= 2.3
        elif w >= 60000: result[i] *= 2.8
        
        result[i] = int(round(result[i], 0))
        print(num,"result :",result[i])
    return result

def make_txt(file):
    cases = 30
    start = t.time()
    result = Solution(cases)
    team = "Counting_Kong"
    date = datetime.datetime.now().strftime("%d-%H-%M-%S")
    time = round(t.time() - start,1)
    file.write("%TEAM\t"+str(team)+"\n")
    file.write("%DATE\t"+str(date)+"\n")
    file.write("%TIME\t"+str(time)+"\n")
    file.write("%CASES\t"+str(cases)+"\n")
    for i in range(1,cases+1):
        if i < 10: num = "0"+str(i)
        else : num = str(i)
        file.write("T"+num+"\t"+str(result[i])+"\n")

f = open("../Out/Kong_Counting_Kong.txt","w")
make_txt(f)
f.close()
